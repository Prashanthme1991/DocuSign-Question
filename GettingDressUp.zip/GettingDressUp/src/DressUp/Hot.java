package DressUp;

public class Hot implements IPutClothes {

	public String putFootWear() {
		return "sandals";
	}

	public String putHeadWear() {
		return "sun visor";
	}

	public String putSocks() {
		return "fail";
	}

	public String putShirt() {
		return "t-shirt";
	}

	public String putJacket() {
		return "fail";
	}

	public String putPants() {
		return "shorts";
	}

	public String leaveHouse() {
		return "leaving house";
	}

	public String takeOffPajamas() {
		return "Removing PJs";
	}
}
