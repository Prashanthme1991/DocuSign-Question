package DressUp;

public interface IDressingUp {
	public String DressingOrder() throws Exception;

}
