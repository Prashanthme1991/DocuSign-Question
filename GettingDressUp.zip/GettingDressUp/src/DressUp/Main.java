package DressUp;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		try {
			Scanner sc = new Scanner(System.in);
			String input = sc.nextLine();
			IDressingUp dressup = new DressUp(input);
			String s = dressup.DressingOrder();
			System.out.println(s);
		} catch (Exception ex) {
			System.out.print(ex);
		}
	}
}
