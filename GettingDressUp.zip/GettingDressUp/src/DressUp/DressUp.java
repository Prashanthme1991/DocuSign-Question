package DressUp;

import java.util.ArrayList;
import java.util.List;

public class DressUp implements IDressingUp {
	private IPutClothes weather;
	private List<String> processedCommands;
	private String failure;
	private InputString process;
	private String input;

	public DressUp(String input) {
		
		processedCommands = new ArrayList<String>();
		failure = "fail";
		this.input = input;
		process = new InputString(input);
	}

	/*
	 * Writing a function to process the input string
	 */
	public String DressingOrder() throws Exception {

		String s[] = process.Input();
		s[0] = s[0].toUpperCase();
		
		if (s[0].equals("HOT")) {
			weather = new Hot();
		} else if (s[0].equals("COLD")) {
			weather = new Cold();
		} else {
			throw new Exception("Invalid input, please enter valid weather value");
		}

		StringBuilder dressingOrder = new StringBuilder();
		
		// Using the StringBuilder to store the dressup order
		try {
			for (int i = 1; i < s.length; i++) {
				String command = s[i];
				if (IsValid(command)) {
					switch (s[i]) {
					case "1":
						dressingOrder.append(", ").append(weather.putFootWear());
						break;
					case "2":
						dressingOrder.append(", ").append(weather.putHeadWear());
						break;
					case "3":
						dressingOrder.append(", ").append(weather.putSocks());
						break;
					case "4":
						dressingOrder.append(", ").append(weather.putShirt());
						break;
					case "5":
						dressingOrder.append(", ").append(weather.putJacket());
						break;
					case "6":
						dressingOrder.append(", ").append(weather.putPants());
						break;
					case "7":
						dressingOrder.append(", ").append(weather.leaveHouse());
						break;
					case "8":
						dressingOrder.append(", ").append(weather.takeOffPajamas());
						break;
					default:
						throw new Exception("Invalid weather specified in the first arguement");
					}
				}
				processedCommands.add(command);
			}
		} catch (Exception ex) {
			if (ex.getMessage().equals(failure)) {
				return dressingOrder.append(", ").append(ex.getMessage()).toString().substring(2);
				
			}

	
			else {
				throw new Exception(ex);
			}
		}
		return (dressingOrder.toString()).substring(2);

	}

	
	 // Check if input command is valid
	 
	private boolean IsValid(String command) throws Exception {

		if (processedCommands.size() == 0) {
			if (!command.equals("8")) {
				throw new Exception(failure);
			}
		}

		
		
		// One piece of clothing can be put on
		if (processedCommands.contains(command)) {
			throw new Exception(failure);
		}

		// You cannot put on socks and jacket when it is hot
	
		if ((command == "3") || (command == "5")) 
		{
			if (weather instanceof Hot) {
				throw new Exception(failure);
			}
		}

	
		//making sure that socks and pants are already put on
		else if (command == "1") {
		
			// check for pants if the weather is hot
			if (weather instanceof Hot) {
				if (!processedCommands.contains("6")) {
					throw new Exception(failure);
				}
			}
			// Or  check for both socks and pants
			else {
				if (!processedCommands.contains("3") || !processedCommands.contains("6")) {
					throw new Exception(failure);
				}
			}
		}

		
		
		// making sure that the shirt is already put on weather it is for headwear or jacket
		else if ((command.equals("2")) || (command.equals("5"))) {
			if (!processedCommands.contains("4")) {
				throw new Exception(failure);
			}
		}

		
		
		//making sure the clothes is on before leaving the house
		else if (command.equals("7")) {
			// Checking  if jacket and socks are put on only if the weather is hot
			if (!(weather instanceof Hot)) // weather is not hot
			{
				if (!processedCommands.contains("3") || !processedCommands.contains("5"))
				// checking if the jacket or shoes/footwear  is not put on
				{
					throw new Exception(failure);
				}
			}

			// Checking  for other types of clothing irrespective of the weather
			
			if (!processedCommands.contains("1") || !processedCommands.contains("2") || !processedCommands.contains("4")
					|| !processedCommands.contains("6") || !processedCommands.contains("8")) {
				throw new Exception(failure);
			}
		}

		
		return true;
	}

}
