package DressUp;

import java.util.ArrayList;
import java.util.List;

public class InputString {
	private String input;
	private List<String> list;
	private String s[];

	public InputString(String input) {
		// TODO Auto-generated constructor stub
		this.input = input;
		list = new ArrayList<String>();
	}

	/*
	 * Reformat the array after splitting
	 */
	public String[] Input() {
		input.trim();
		s = input.split(",|\\ ");
		for (int i = 0; i < s.length; i++) {
			s[i].trim();
			if (!s[i].isEmpty()) {
				list.add(s[i]);
			}
		}
		return list.toArray(new String[list.size()]);
	}

}
