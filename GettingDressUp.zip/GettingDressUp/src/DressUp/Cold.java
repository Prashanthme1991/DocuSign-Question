package DressUp;

public class Cold implements IPutClothes {
	public String putFootWear() {
		return "boots";
	}

	public String putHeadWear() {
		return "hat";
	}

	public String putSocks() {
		return "socks";
	}

	public String putShirt() {
		return "shirt";
	}

	public String putJacket() {
		return "jacket";
	}

	public String putPants() {
		return "pants";
	}

	public String leaveHouse() {
		return "leaving house";
	}

	public String takeOffPajamas() {
		return "Removing PJs";
	}

}
